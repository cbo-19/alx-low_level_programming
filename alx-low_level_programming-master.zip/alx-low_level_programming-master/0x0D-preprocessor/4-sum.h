#ifndef _SUM_H
#define _SUM_H
#define SUM(x, y) (x + y)
#endif
