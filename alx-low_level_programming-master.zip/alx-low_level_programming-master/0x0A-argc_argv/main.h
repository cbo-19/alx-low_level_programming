int _putchar(char c);
int atoi(char j[]);
