#include <unistd.h>
/**
 * main - this program prints putchar using putchar function
 *
 * Return: 0
 */

int main(void)
{
	write(1, "_putchar\n", 9);
	return (0);
}






















