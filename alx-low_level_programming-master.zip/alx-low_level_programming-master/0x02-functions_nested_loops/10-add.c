#include "main.h"
/**
 * add - thi program prints every minute
 *
 * @n: first value
 * @m: second value
 *
 * Return: minutes
 */
int add(int n, int m)
{
	int result = n + m;

	return (result);
}
