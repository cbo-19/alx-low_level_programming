#include "main.h"
/**
 * set_string - sets pointer val to char
 * @s: pointer
 * @to: char
 */
void set_string(char **s, char *to)
{
	*s = to;
}
