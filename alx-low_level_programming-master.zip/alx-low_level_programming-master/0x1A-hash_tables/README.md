C - Hash tables
