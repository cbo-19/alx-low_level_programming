0x1E. C - Search Algorithms
