#include "main.h"

/**
 * _isupper - check the code for Holberton School students.
 *
 * @c: is an integer param
 *
 * Return: Always 0.
 */


int _isupper(int c)
{

	return (c >= 65 && c <= 90);
}
