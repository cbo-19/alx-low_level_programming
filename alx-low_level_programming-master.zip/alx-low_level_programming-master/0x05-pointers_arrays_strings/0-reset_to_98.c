/**
 * reset_to_98 - this function update the value to 98
 *
 * @n: value
 */
void reset_to_98(int *n)
{
	*n = 98;
}
