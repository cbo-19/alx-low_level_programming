/*this is a puthcar function*/
int _putchar(char c);
/*this function change the value it points to 98*/
void reset_to_98(int *n);
 /*this function swaps the value of two integers*/
void swap_int(int *a, int *b);
/*this function returns the length of a string*/
int _strlen(char *s);
/*this function prints a string*/
void _puts(char *str);
/*this function prints a string in reverse*/
void print_rev(char *s);
/*this function prints a string and its reversa*/
void rev_string(char *s);
/*this function prints every other character*/
void puts2(char *str);
/*this function prints half of a string*/
void puts_half(char *str);
/*this funtcion prints n elements of an array*/
void print_array(int *a, int n);
/*this function copies from a pointer to another*/
char *_strcpy(char *dest, char *src);
int _atoi(char *s);
