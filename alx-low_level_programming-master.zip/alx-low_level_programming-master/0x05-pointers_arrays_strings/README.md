arrays and strings
