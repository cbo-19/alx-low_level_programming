C - Dynamic libraries
