More pointers, arrays and strings
