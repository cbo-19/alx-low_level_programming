#include "main.h"
/**
 * mul - this function multiplies two values
 *
 * @a: character value
 * @b: character value
 *
 * Return: result
 */
int mul(int a, int b)
{
	int result;

	result = a * b;
	return (result);

}
